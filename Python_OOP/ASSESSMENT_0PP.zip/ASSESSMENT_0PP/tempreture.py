user_input = input("Enter the tempreture in Celsius: ")
celsius = float(user_input)
fahrenheit = (celsius * 9/5) + 32
print(f"The tempreture in Fahrenheit is {fahrenheit}")
print("The tempreture in Fahrenheit is " + str(fahrenheit))


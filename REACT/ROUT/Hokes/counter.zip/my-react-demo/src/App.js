import React from 'react';
import './App.css';
import Counter from './components/counter'; // Adjust the path if necessary

function App() {
  return (
    <div className="App">
      <Counter />
    </div>
  );
}

export default App;